/*------------------------------------------------------------------------
 * filename - wep.c
 *
 * function(s)
 *        __WEP - default DLL cleanup function, called if
 *                user program doesn't define one
 *-----------------------------------------------------------------------*/

/*
 *      C/C++ Run Time Library - Version 5.0
 *
 *      Copyright (c) 1987, 1992 by Borland International
 *      All Rights Reserved.
 *
 */

#pragma argsused

int far pascal __WEP( int i )
{
    return 1;
}
